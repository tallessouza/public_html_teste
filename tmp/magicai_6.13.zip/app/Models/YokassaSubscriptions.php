<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class YokassaSubscriptions extends Model
{
    protected $table = 'subscriptions_yokassa';

    protected $guarded = [];
}
