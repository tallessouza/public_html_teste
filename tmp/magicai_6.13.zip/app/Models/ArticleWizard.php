<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArticleWizard extends Model
{
    protected $table = 'article_wizard';

    protected $guarded = [];
}
