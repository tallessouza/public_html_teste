<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FrontendSectionsStatusses extends Model
{
    use HasFactory;

    protected $table = 'frontend_sections_statuses_titles';
}
