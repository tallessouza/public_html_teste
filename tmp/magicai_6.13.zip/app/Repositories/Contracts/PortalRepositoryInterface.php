<?php

namespace App\Repositories\Contracts;

interface PortalRepositoryInterface
{
    public function domainKey();
}