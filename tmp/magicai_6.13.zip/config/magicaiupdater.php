<?php

return [

    'tmp_folder_name' => 'tmp',

    'script_filename' => 'upgrade.php',

    'update_baseurl' => 'https://api.liquid-themes.com/magicai/updater-v2',

];
