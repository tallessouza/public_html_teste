<?php
/*
* @author: Pietro Cinaglia
* https://github.com/pietrocinaglia
*/

	return [

		'tmp_folder_name' => 'tmp',

		'script_filename' => 'upgrade.php',

		'update_baseurl' => 'https://api.liquid-themes.com/magicai/update-temporary',

		'middleware' => ['web', 'auth'],

		'allow_users_id' => [1]
	];
